#include <iostream>
#include <string>
#include <limits>

const int MAX_INPUT_SIZE = 10; // Maximum allowed input size

void collectAndDisplayNumber() {
    std::string userInput;

    std::cout << "Enter a number: ";
    std::getline(std::cin, userInput);

    // Prevent buffer overflow by ensuring input doesn't exceed the buffer size
    if (userInput.length() > MAX_INPUT_SIZE) {
        std::cerr << "Input too long. Account number remains secure." << std::endl;
        return;
    }

    // Display the user's input and a secret account number
    std::cout << "User Input: " << userInput << std::endl;
    std::cout << "Secret Account Number: XXXX-XXXX-XXXX-XXXX" << std::endl;
}

int main() {
    collectAndDisplayNumber();

    return 0;
}
