#include "pch.h"
#include "gtest/gtest.h"
#include <vector>
#include <cstdlib>
#include <ctime>

class Environment : public ::testing::Environment
{
public:
  ~Environment() override {}

  void SetUp() override
  {
    srand(time(nullptr));
  }

  void TearDown() override {}
};

class CollectionTest : public ::testing::Test
{
protected:
  std::unique_ptr<std::vector<int>> collection;

  void SetUp() override
  {
    collection.reset(new std::vector<int>);
  }

  void TearDown() override
  {
    collection->clear();
    collection.reset(nullptr);
  }

  void add_entries(int count)
  {
    assert(count > 0);
    for (auto i = 0; i < count; ++i)
      collection->push_back(rand() % 100);
  }
};

TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
  ASSERT_TRUE(collection);
  ASSERT_NE(collection.get(), nullptr);
}

TEST_F(CollectionTest, IsEmptyOnCreate)
{
  ASSERT_TRUE(collection->empty());
  ASSERT_EQ(collection->size(), 0);
}

TEST_F(CollectionTest, AlwaysFail)
{
  FAIL();
}

TEST_F(CollectionTest, CanAddToEmptyVector)
{
  ASSERT_TRUE(collection->empty());
  ASSERT_EQ(collection->size(), 0);

  add_entries(1);

  ASSERT_FALSE(collection->empty());
  ASSERT_EQ(collection->size(), 1);
}

TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
  add_entries(5);
  ASSERT_EQ(collection->size(), 5);
}

TEST_F(CollectionTest, MaxSizeGreaterThanOrEqualToSize)
{
  const int sizes[] = {0, 1, 5, 10};
  for (int size : sizes) {
    collection->clear();
    add_entries(size);
    ASSERT_GE(collection->max_size(), collection->size());
  }
}

TEST_F(CollectionTest, CapacityGreaterThanOrEqualToSize)
{
  const int sizes[] = {0, 1, 5, 10};
  for (int size : sizes) {
    collection->clear();
    add_entries(size);
    ASSERT_GE(collection->capacity(), collection->size());
  }
}

TEST_F(CollectionTest, ResizeIncreasesCollection)
{
  add_entries(5);
  size_t originalSize = collection->size();
  size_t newSize = originalSize + 3;
  collection->resize(newSize);
  ASSERT_EQ(collection->size(), newSize);
  ASSERT_GE(collection->capacity(), newSize);
}

TEST_F(CollectionTest, ResizeDecreasesCollection)
{
  add_entries(5);
  size_t originalSize = collection->size();
  size_t newSize = originalSize - 2;
  collection->resize(newSize);
  ASSERT_EQ(collection->size(), newSize);
  ASSERT_GE(collection->capacity(), originalSize); // Capacity should not decrease
}

TEST_F(CollectionTest, ResizeDecreasesCollectionToZero)
{
  add_entries(5);
  collection->resize(0);
  ASSERT_TRUE(collection->empty());
  ASSERT_EQ(collection->size(), 0);
}

TEST_F(CollectionTest, ClearErasesCollection)
{
  add_entries(5);
  collection->clear();
  ASSERT_TRUE(collection->empty());
  ASSERT_EQ(collection->size(), 0);
}

TEST_F(CollectionTest, EraseBeginToEndErasesCollection)
{
  add_entries(5);
  collection->erase(collection->begin(), collection->end());
  ASSERT_TRUE(collection->empty());
  ASSERT_EQ(collection->size(), 0);
}

TEST_F(CollectionTest, ReserveIncreasesCapacity)
{
  size_t originalCapacity = collection->capacity();
  size_t newCapacity = originalCapacity + 5;
  collection->reserve(newCapacity);
  ASSERT_GE(collection->capacity(), newCapacity);
  ASSERT_EQ(collection->size(), 0);
}

TEST_F(CollectionTest, OutOfRangeExceptionThrown)
{
  add_entries(5);
  ASSERT_THROW(collection->at(10), std::out_of_range);
}

// Custom positive test
TEST_F(CollectionTest, CustomPositiveTest)
{
  // Custom positive test scenario:
  // Verify that the collection contains values greater than or equal to 50
  add_entries(5);
  for (const auto& value : *collection) {
    ASSERT_GE(value, 50);
  }
}

// Custom negative test
TEST_F(CollectionTest, CustomNegativeTest)
{
  // Custom negative test scenario:
  // Verify that an empty collection throws an exception when attempting to access an element
  ASSERT_TRUE(collection->empty());

  // Attempt to access an element in an empty collection should throw an exception
  ASSERT_THROW(collection->at(0), std::out_of_range);
}

int main(int argc, char** argv)
{
  ::testing::InitGoogleTest(&argc, argv);
  ::testing::AddGlobalTestEnvironment(new Environment);
  return RUN_ALL_TESTS();
}
